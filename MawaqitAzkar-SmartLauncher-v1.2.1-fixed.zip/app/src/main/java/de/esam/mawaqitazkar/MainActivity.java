package de.esam.mawaqitazkar;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.widget.*;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(5, 12, 29);
    private final int PANEL = Color.rgb(12, 24, 48);
    private final int GOLD = Color.rgb(245, 195, 91);
    private final int WHITE = Color.rgb(245, 247, 252);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService net = Executors.newSingleThreadExecutor();
    private TextView clock, date, hijri, weather, prayer, nextPrayer, dhikr, status;
    private WebView video;
    private EditText urlInput;
    private LinearLayout dashboardRoot, dashboardTop, dashboardBody, dashboardDock, videoPanel;
    private View infoContainer, videoTitleView, videoControls, playButton, appsButton;
    private Button videoExpandButton, uiFullscreenButton, videoBackButton;
    private boolean videoExpanded = false;
    private boolean immersiveUi = false;
    private String prayerTimes = "الفجر --:--  •  الظهر --:--\\nالعصر --:--  •  المغرب --:--  •  العشاء --:--";
    private final String[] adhkar = {
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
        "أستغفر الله العظيم وأتوب إليه",
        "لا إله إلا الله وحده لا شريك له",
        "اللهم صلِّ وسلم على نبينا محمد",
        "سبحان الله، والحمد لله، ولا إله إلا الله، والله أكبر",
        "لا حول ولا قوة إلا بالله"
    };
    private int dhikrIndex = 0;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(18));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setPadding(dp(7), dp(5), dp(7), dp(5)); return t;
    }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private LinearLayout.LayoutParams weight(int w, float wt) { return new LinearLayout.LayoutParams(0, w, wt); }
    private void addGap(LinearLayout l, int h) { View v = new View(this); l.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildDashboard();
        updateClock();
        refreshData();
        handler.post(ticker);
        handler.postDelayed(refreshTicker, 30 * 60 * 1000);
    }

    private void buildDashboard() {
        LinearLayout root = vertical();
        dashboardRoot = root;
        root.setBackgroundColor(BG);
        root.setPadding(dp(10), dp(10), dp(10), dp(10));

        LinearLayout top = horizontal();
        dashboardTop = top;
        TextView brand = label("مواقيت وأذكار", 24, GOLD, true);
        brand.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1));
        TextView city = label("KIEL • DEUTSCHLAND", 11, WHITE, true);
        top.addView(city);
        root.addView(top);

        boolean landscapeDashboard = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE
            || getResources().getConfiguration().smallestScreenWidthDp >= 600;
        LinearLayout body = landscapeDashboard ? horizontal() : vertical();
        dashboardBody = body;
        LinearLayout info = vertical();
        info.setPadding(dp(8), dp(8), dp(8), dp(8));
        try {
            android.graphics.Bitmap kaabaBitmap = android.graphics.BitmapFactory.decodeResource(getResources(), R.drawable.kaaba_background);
            android.graphics.drawable.BitmapDrawable kaabaDrawable = new android.graphics.drawable.BitmapDrawable(getResources(), kaabaBitmap);
            kaabaDrawable.setGravity(Gravity.FILL);
            android.graphics.drawable.LayerDrawable infoBg = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[] {
                kaabaDrawable, new android.graphics.drawable.ColorDrawable(0xD90A1830)
            });
            info.setBackground(infoBg);
        } catch (Exception ignored) { info.setBackground(shape(PANEL, 0x665B78A5)); }
        clock = label("--:--", 34, WHITE, true); info.addView(clock);
        date = label("", 13, 0xFFD8E1EF, false); info.addView(date);
        hijri = label("التاريخ الهجري: جارٍ التحميل", 14, GOLD, true); info.addView(hijri);
        addGap(info, 5);
        weather = label("🌤️ الطقس: جارٍ التحميل", 16, WHITE, true); info.addView(weather);
        addGap(info, 6);
        TextView heading = label("مواقيت الصلاة", 19, GOLD, true); info.addView(heading);
        prayer = label(prayerTimes, 15, WHITE, true); info.addView(prayer);
        nextPrayer = label("جارٍ حساب الصلاة القادمة", 14, 0xFF9FE6B7, true);
        nextPrayer.setBackground(shape(0xCC0A4937, 0xFF248B68)); info.addView(nextPrayer);
        addGap(info, 6);
        TextView dh = label("ذكر اليوم", 16, GOLD, true); info.addView(dh);
        dhikr = label(adhkar[0], 17, WHITE, true);
        dhikr.setMinHeight(dp(68)); dhikr.setBackground(shape(0xAA1B2946, 0x667C91B8)); info.addView(dhikr);
        dhikr.setOnClickListener(v -> { dhikrIndex = (dhikrIndex + 1) % adhkar.length; dhikr.setText(adhkar[dhikrIndex]); });
        LinearLayout videoPanel = vertical();
        this.videoPanel = videoPanel;
        videoPanel.setPadding(dp(8), dp(8), dp(8), dp(8));
        videoPanel.setBackground(shape(0xFF101B31, 0xFFB98A39));
        TextView videoTitle = label("مشاهدة YouTube أو القنوات", 17, GOLD, true);
        videoTitleView = videoTitle;
        videoPanel.addView(videoTitle, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout viewControls = horizontal();
        videoControls = viewControls;
        videoExpandButton = new Button(this);
        videoExpandButton.setText(videoExpanded ? "إعادة الواجهة" : "تكبير الفيديو");
        viewControls.addView(videoExpandButton, new LinearLayout.LayoutParams(0, dp(40), 1));
        uiFullscreenButton = new Button(this);
        uiFullscreenButton.setText(immersiveUi ? "إظهار أشرطة النظام" : "تكبير الواجهة");
        viewControls.addView(uiFullscreenButton, new LinearLayout.LayoutParams(0, dp(40), 1));
        videoPanel.addView(viewControls, new LinearLayout.LayoutParams(-1, dp(44)));
        videoBackButton = new Button(this);
        videoBackButton.setText("العودة إلى مواقيت الصلاة والواجهة الرئيسية  ↩");
        videoBackButton.setVisibility(videoExpanded ? View.VISIBLE : View.GONE);
        videoPanel.addView(videoBackButton, new LinearLayout.LayoutParams(-1, dp(42)));
        videoExpandButton.setOnClickListener(v -> setVideoExpanded(!videoExpanded));
        videoBackButton.setOnClickListener(v -> setVideoExpanded(false));
        uiFullscreenButton.setOnClickListener(v -> setImmersiveUi(!immersiveUi));

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextColor(WHITE); urlInput.setHintTextColor(0xFF9AAAC0);
        urlInput.setHint("ضع رابط فيديو YouTube هنا");
        urlInput.setTextSize(13);
        urlInput.setPadding(dp(10), 0, dp(10), 0);
        urlInput.setBackground(shape(0xFF26334B, 0xFF526987));
        videoPanel.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(42)));

        Button play = new Button(this); play.setText("تشغيل الفيديو");
        playButton = play;
        videoPanel.addView(play, new LinearLayout.LayoutParams(-1, dp(42)));

        Button apps = new Button(this);
        appsButton = apps;
        apps.setText("فتح تطبيق IPTV أو تطبيق آخر");
        videoPanel.addView(apps, new LinearLayout.LayoutParams(-1, dp(42)));
        apps.setOnClickListener(v -> showInstalledApps());

        video = new WebView(this);
        video.setBackgroundColor(Color.BLACK);
        WebSettings ws = video.getSettings();
        ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true);
        ws.setMediaPlaybackRequiresUserGesture(true);
        video.setWebChromeClient(new WebChromeClient());
        video.setWebViewClient(new WebViewClient());
        videoPanel.addView(video, new LinearLayout.LayoutParams(-1, 0, 1));
        play.setOnClickListener(v -> loadVideo(urlInput.getText().toString().trim()));
        status = label("أدخل رابط YouTube لتشغيله هنا. القنوات الخارجية تُفتح في تطبيقها.", 12, 0xFFB9C5D7, false);
        videoPanel.addView(status);
        ScrollView infoScroll = new ScrollView(this);
        infoContainer = infoScroll;
        infoScroll.setFillViewport(false);
        infoScroll.setVerticalScrollBarEnabled(true);
        infoScroll.addView(info, new ScrollView.LayoutParams(-1, -2));
        if (landscapeDashboard) {
            body.setGravity(Gravity.TOP);
            body.addView(infoScroll, new LinearLayout.LayoutParams(0, -1, 0.40f));
            LinearLayout.LayoutParams videoLp = new LinearLayout.LayoutParams(0, -1, 0.60f);
            videoLp.setMargins(dp(6), 0, 0, 0);
            body.addView(videoPanel, videoLp);
        } else {
            body.addView(infoScroll, new LinearLayout.LayoutParams(-1, 0, 0.48f));
            LinearLayout.LayoutParams videoLp = new LinearLayout.LayoutParams(-1, 0, 0.52f);
            videoLp.topMargin = dp(6);
            body.addView(videoPanel, videoLp);
        }
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout dock = horizontal();
        dashboardDock = dock;
        dock.setGravity(Gravity.CENTER);
        addDockButton(dock, "YouTube", () -> { urlInput.setText("https://www.youtube.com"); loadVideo("https://www.youtube.com"); });
        addDockButton(dock, "القنوات", () -> showInstalledApps());
        addDockButton(dock, "تطبيقاتي", () -> showInstalledApps());
        addDockButton(dock, "القرآن", () -> loadVideo("https://quran.com"));
        addDockButton(dock, "الأذكار", () -> { dhikrIndex=(dhikrIndex+1)%adhkar.length; dhikr.setText(adhkar[dhikrIndex]); });
        addDockButton(dock, "إعدادات", () -> Toast.makeText(this, "إعدادات العرض والمدينة قيد التطوير", Toast.LENGTH_SHORT).show());
        root.addView(dock, new LinearLayout.LayoutParams(-1, dp(58)));
        setContentView(root);
        applyDisplayModes();
    }

    private void setVideoExpanded(boolean expanded) {
        videoExpanded = expanded;
        applyDisplayModes();
    }

    private void setImmersiveUi(boolean enabled) {
        immersiveUi = enabled;
        applyDisplayModes();
    }

    private void applyDisplayModes() {
        if (dashboardTop == null || dashboardBody == null || dashboardDock == null || infoContainer == null || videoPanel == null) return;
        dashboardTop.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        infoContainer.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        dashboardDock.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        videoPanel.setBackground(videoExpanded ? new android.graphics.drawable.ColorDrawable(Color.BLACK) : shape(0xFF101B31, 0xFFB98A39));
        if (videoExpandButton != null) videoExpandButton.setText(videoExpanded ? "إعادة الواجهة" : "تكبير الفيديو");
        if (videoBackButton != null) videoBackButton.setVisibility(videoExpanded ? View.VISIBLE : View.GONE);
        if (videoTitleView != null) videoTitleView.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        if (videoControls != null) videoControls.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        if (urlInput != null) urlInput.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        if (playButton != null) playButton.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        if (appsButton != null) appsButton.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        if (status != null) status.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        if (uiFullscreenButton != null) uiFullscreenButton.setText(immersiveUi ? "إظهار أشرطة النظام" : "تكبير الواجهة");
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        if (immersiveUi || videoExpanded) {
            flags |= View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
        LinearLayout.LayoutParams bodyLp = (LinearLayout.LayoutParams) dashboardBody.getLayoutParams();
        bodyLp.width = -1; bodyLp.height = 0; bodyLp.weight = 1f;
        dashboardBody.setLayoutParams(bodyLp);
        if (videoExpanded) {
            dashboardBody.setOrientation(LinearLayout.VERTICAL);
            dashboardBody.removeView(infoContainer);
            if (videoPanel.getParent() instanceof ViewGroup) ((ViewGroup) videoPanel.getParent()).removeView(videoPanel);
            dashboardBody.addView(videoPanel, new LinearLayout.LayoutParams(-1, 0, 1f));
        } else {
            // The normal dashboard is rebuilt on orientation changes; restore its original two-column/stacked layout.
            if (videoPanel.getParent() instanceof ViewGroup) ((ViewGroup) videoPanel.getParent()).removeView(videoPanel);
            if (infoContainer.getParent() instanceof ViewGroup) ((ViewGroup) infoContainer.getParent()).removeView(infoContainer);
            boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE || getResources().getConfiguration().smallestScreenWidthDp >= 600;
            dashboardBody.setOrientation(landscape ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
            if (landscape) {
                dashboardBody.addView(infoContainer, new LinearLayout.LayoutParams(0, -1, 0.40f));
                LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(0, -1, 0.60f); vp.setMargins(dp(6), 0, 0, 0);
                dashboardBody.addView(videoPanel, vp);
            } else {
                dashboardBody.addView(infoContainer, new LinearLayout.LayoutParams(-1, 0, 0.48f));
                LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, 0, 0.52f); vp.topMargin = dp(6);
                dashboardBody.addView(videoPanel, vp);
            }
        }
    }

    private void addDockButton(LinearLayout dock, String name, Runnable action) {
        Button b = new Button(this); b.setText(name); b.setTextSize(11);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1);
        lp.setMargins(dp(2), 0, dp(2), 0); dock.addView(b, lp);
        b.setOnClickListener(v -> action.run());
    }

    private void loadVideo(String url) {
        if (url == null || url.isEmpty()) { status.setText("أدخل رابط YouTube أولاً."); return; }
        if (url.equals("https://www.youtube.com") || url.equals("https://quran.com")) {
            video.loadUrl(url); status.setText("تم فتح الموقع داخل إطار المشاهدة."); return;
        }
        String id = extractYoutubeId(url);
        if (id == null) { video.loadUrl(url); status.setText("فتح الرابط داخل إطار المشاهدة."); return; }
        String html = "<html><body style='margin:0;background:#000'><iframe width='100%' height='100%' src='https://www.youtube.com/embed/" +
            id + "?playsinline=1&rel=0' frameborder='0' allow='autoplay; encrypted-media; picture-in-picture; fullscreen' allowfullscreen></iframe></body></html>";
        video.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null);
        status.setText("فيديو YouTube مضمّن. قد تمنع بعض المقاطع التشغيل داخل WebView.");
    }
    private String extractYoutubeId(String u) {
        try {
            Uri uri = Uri.parse(u);
            String host = uri.getHost() == null ? "" : uri.getHost();
            if (host.contains("youtu.be")) return uri.getLastPathSegment();
            if (host.contains("youtube.com")) {
                if (uri.getPath() != null && uri.getPath().startsWith("/embed/")) return uri.getLastPathSegment();
                return uri.getQueryParameter("v");
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void showInstalledApps() {
        ArrayList<String> labels = new ArrayList<>();
        ArrayList<String> packages = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();

        Intent launcher = new Intent(Intent.ACTION_MAIN);
        launcher.addCategory(Intent.CATEGORY_LAUNCHER);
        collectApps(launcher, labels, packages, seen);

        Intent leanback = new Intent(Intent.ACTION_MAIN);
        leanback.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        collectApps(leanback, labels, packages, seen);

        if (labels.isEmpty()) {
            Toast.makeText(this, "لم يتم العثور على تطبيقات قابلة للتشغيل.", Toast.LENGTH_LONG).show();
            return;
        }

        String[] names = labels.toArray(new String[0]);
        new android.app.AlertDialog.Builder(this)
            .setTitle("اختر التطبيق الذي تريد فتحه")
            .setItems(names, (dialog, which) -> openInstalledApp(packages.get(which)))
            .setNegativeButton("إغلاق", null)
            .show();
    }

    private void collectApps(Intent query, ArrayList<String> labels, ArrayList<String> packages, HashSet<String> seen) {
        List<ResolveInfo> found = getPackageManager().queryIntentActivities(query, 0);
        for (ResolveInfo info : found) {
            String pkg = info.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;
            CharSequence label = info.loadLabel(getPackageManager());
            labels.add(label == null ? pkg : label.toString());
            packages.add(pkg);
        }
    }

    private void openInstalledApp(String packageName) {
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
            if (launch == null) {
                launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
                launch.setPackage(packageName);
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر فتح التطبيق. جرّب تشغيله من قائمة تطبيقات الهاتف.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        buildDashboard();
        updateClock();
        refreshData();
    }

    private Runnable ticker = new Runnable() {
        @Override public void run() {
            updateClock();
            handler.postDelayed(this, 1000);
        }
    };
    private Runnable refreshTicker = new Runnable() {
        @Override public void run() { refreshData(); handler.postDelayed(this, 30*60*1000); }
    };
    private void updateClock() {
        Date now = new Date();
        if (clock != null) clock.setText(new SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(now));
        if (date != null) date.setText(new SimpleDateFormat("EEEE، dd.MM.yyyy", new Locale("ar")).format(now));
    }
    private void refreshData() {
        net.execute(() -> {
            try {
                String raw = get("https://api.aladhan.com/v1/timings?latitude=54.3233&longitude=10.1228&method=3");
                JSONObject data = new JSONObject(raw).getJSONObject("data");
                JSONObject t = data.getJSONObject("timings");
                String pt = "الفجر " + clean(t.optString("Fajr")) + "  •  الظهر " + clean(t.optString("Dhuhr")) +
                    "\\nالعصر " + clean(t.optString("Asr")) + "  •  المغرب " + clean(t.optString("Maghrib")) +
                    "  •  العشاء " + clean(t.optString("Isha"));
                JSONObject h = data.getJSONObject("date").getJSONObject("hijri");
                String ht = "التاريخ الهجري: " + h.optString("day") + " " +
                    h.getJSONObject("month").optString("ar") + " " + h.optString("year") + " هـ";
                runOnUiThread(() -> { prayer.setText(pt); hijri.setText(ht); nextPrayer.setText("مواقيت الصلاة محدّثة لمدينة كيل"); });
            } catch (Exception e) { runOnUiThread(() -> status.setText("تعذر تحديث مواقيت الصلاة. تحقق من الإنترنت.")); }
            try {
                String raw = get("https://api.open-meteo.com/v1/forecast?latitude=54.3233&longitude=10.1228&current=temperature_2m,apparent_temperature&timezone=Europe%2FBerlin");
                JSONObject cur = new JSONObject(raw).getJSONObject("current");
                String wt = "🌤️ كيل: " + cur.optDouble("temperature_2m") + "°C  •  المحسوسة " + cur.optDouble("apparent_temperature") + "°C";
                runOnUiThread(() -> weather.setText(wt));
            } catch (Exception ignored) {}
        });
    }
    private String get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(u).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(10000);
        try (InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] b=new byte[4096]; int n; while((n=in.read(b))!=-1) out.write(b,0,n);
            return out.toString("UTF-8");
        } finally { c.disconnect(); }
    }
    private String clean(String s) { return s == null ? "--:--" : s.split(" ")[0]; }
    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null); net.shutdownNow();
        if (video != null) { video.loadUrl("about:blank"); video.destroy(); }
        super.onDestroy();
    }
}
