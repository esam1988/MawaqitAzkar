package de.esam.mawaqitazkar;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(24));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF102820);

        TextView title = new TextView(this);
        title.setText("مواقيت وأذكار");
        title.setTextColor(0xFFFFD98A);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(58)));

        TextView desc = new TextView(this);
        desc.setText("لوحة إسلامية عائمة فوق YouTube والتطبيقات الأخرى\\n\\nالموقع الحالي: كيل – ألمانيا\\nتعرض الساعة والتاريخ الهجري والطقس ومواقيت الصلاة والأذكار.");
        desc.setTextColor(0xFFF1F5F2);
        desc.setTextSize(17);
        desc.setGravity(Gravity.CENTER);
        desc.setPadding(0, dp(12), 0, dp(24));
        root.addView(desc);

        Button start = new Button(this);
        start.setText("تشغيل النافذة العائمة");
        root.addView(start, new LinearLayout.LayoutParams(-1, dp(56)));
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
                startActivity(i);
                Toast.makeText(this, "فعّل السماح بالظهور فوق التطبيقات ثم ارجع واضغط تشغيل", Toast.LENGTH_LONG).show();
            } else {
                Intent s = new Intent(this, OverlayService.class);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
                Toast.makeText(this, "تم تشغيل اللوحة العائمة", Toast.LENGTH_SHORT).show();
            }
        });

        Button stop = new Button(this);
        stop.setText("إيقاف النافذة العائمة");
        root.addView(stop, new LinearLayout.LayoutParams(-1, dp(52)));
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));

        TextView note = new TextView(this);
        note.setText("اسحب النافذة من شريطها العلوي لتحريكها. اضغط × لإغلاقها.\\nمواقيت الصلاة والطقس يحتاجان إلى اتصال بالإنترنت.");
        note.setTextColor(0xFFB8C9C0);
        note.setTextSize(14);
        note.setGravity(Gravity.CENTER);
        note.setPadding(0, dp(22), 0, 0);
        root.addView(note);

        setContentView(root);
    }
}
