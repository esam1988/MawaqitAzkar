package de.esam.mawaqitazkar;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.widget.*;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(5, 12, 29);
    private final int PANEL = Color.rgb(12, 24, 48);
    private final int GOLD = Color.rgb(245, 195, 91);
    private final int WHITE = Color.rgb(245, 247, 252);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService net = Executors.newSingleThreadExecutor();

    private TextView clock, date, hijri, weather, prayer, nextPrayer, dhikr, status;
    private EditText urlInput;
    private PlayerView playerView;
    private WebView webView;
    private FrameLayout videoHost;
    private ExoPlayer exoPlayer;
    private LinearLayout dashboardTop, dashboardBody, dashboardDock, videoPanel;
    private View infoContainer, videoTitleView, videoControls, playButton, playlistButton;
    private Button videoExpandButton, uiFullscreenButton, videoBackButton;
    private boolean videoExpanded = false;
    private boolean immersiveUi = false;
    private boolean showingWebContent = false;
    private final String[] adhkar = {
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
        "أستغفر الله العظيم وأتوب إليه",
        "لا إله إلا الله وحده لا شريك له",
        "اللهم صلِّ وسلم على نبينا محمد",
        "سبحان الله، والحمد لله، ولا إله إلا الله، والله أكبر",
        "لا حول ولا قوة إلا بالله"
    };
    private int dhikrIndex = 0;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(18));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setPadding(dp(7), dp(5), dp(7), dp(5)); return t;
    }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout horizontal() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildDashboard();
        updateClock();
        refreshData();
        handler.post(ticker);
        handler.postDelayed(refreshTicker, 30 * 60 * 1000);
    }

    @Override protected void onStart() {
        super.onStart();
        initializePlayer();
    }

    private void initializePlayer() {
        if (exoPlayer == null) {
            exoPlayer = new ExoPlayer.Builder(this).build();
            exoPlayer.addListener(new Player.Listener() {
                @Override public void onPlayerError(PlaybackException error) {
                    if (status != null) status.setText("تعذر تشغيل البث: " + error.getErrorCodeName() + " — تحقق من رابط البث أو توافق الصيغة.");
                }
                @Override public void onPlaybackStateChanged(int state) {
                    if (status == null) return;
                    if (state == Player.STATE_BUFFERING) status.setText("جارٍ تحميل البث…");
                    else if (state == Player.STATE_READY) status.setText("البث يعمل داخل Smart Launcher.");
                    else if (state == Player.STATE_ENDED) status.setText("انتهى التشغيل.");
                }
            });
        }
        if (playerView != null) playerView.setPlayer(exoPlayer);
    }

    @Override protected void onStop() {
        if (playerView != null) playerView.setPlayer(null);
        if (exoPlayer != null) { exoPlayer.release(); exoPlayer = null; }
        super.onStop();
    }

    private void buildDashboard() {
        LinearLayout root = vertical();
        root.setBackgroundColor(BG);
        root.setPadding(dp(10), dp(10), dp(10), dp(10));

        LinearLayout top = horizontal();
        dashboardTop = top;
        TextView brand = label("مواقيت وأذكار", 24, GOLD, true);
        brand.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        top.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1));
        top.addView(label("KIEL • DEUTSCHLAND", 11, WHITE, true));
        root.addView(top);

        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE
            || getResources().getConfiguration().smallestScreenWidthDp >= 600;
        LinearLayout body = landscape ? horizontal() : vertical();
        dashboardBody = body;

        LinearLayout info = vertical();
        info.setPadding(dp(8), dp(8), dp(8), dp(8));
        try {
            android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeResource(getResources(), R.drawable.kaaba_background);
            android.graphics.drawable.BitmapDrawable kaaba = new android.graphics.drawable.BitmapDrawable(getResources(), bitmap);
            kaaba.setGravity(Gravity.FILL);
            info.setBackground(new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{
                kaaba, new android.graphics.drawable.ColorDrawable(0xD90A1830)
            }));
        } catch (Exception ignored) { info.setBackground(shape(PANEL, 0x665B78A5)); }

        clock = label("--:--", 34, WHITE, true); info.addView(clock);
        date = label("", 13, 0xFFD8E1EF, false); info.addView(date);
        hijri = label("التاريخ الهجري: جارٍ التحميل", 14, GOLD, true); info.addView(hijri);
        info.addView(label("🌤️ الطقس", 15, GOLD, true));
        weather = label("جارٍ التحميل…", 16, WHITE, true); info.addView(weather);
        info.addView(label("مواقيت الصلاة", 19, GOLD, true));
        prayer = label("الفجر --:--  •  الظهر --:--\nالعصر --:--  •  المغرب --:--  •  العشاء --:--", 15, WHITE, true);
        info.addView(prayer);
        nextPrayer = label("جارٍ حساب الصلاة القادمة", 14, 0xFF9FE6B7, true);
        nextPrayer.setBackground(shape(0xCC0A4937, 0xFF248B68)); info.addView(nextPrayer);
        info.addView(label("ذكر اليوم", 16, GOLD, true));
        dhikr = label(adhkar[0], 17, WHITE, true);
        dhikr.setMinHeight(dp(68)); dhikr.setBackground(shape(0xAA1B2946, 0x667C91B8)); info.addView(dhikr);
        dhikr.setOnClickListener(v -> { dhikrIndex = (dhikrIndex + 1) % adhkar.length; dhikr.setText(adhkar[dhikrIndex]); });

        LinearLayout video = vertical();
        videoPanel = video;
        video.setPadding(dp(8), dp(8), dp(8), dp(8));
        video.setBackground(shape(0xFF101B31, 0xFFB98A39));
        videoTitleView = label("مشغل القنوات والفيديو المدمج", 17, GOLD, true);
        video.addView(videoTitleView, new LinearLayout.LayoutParams(-1, dp(36)));

        LinearLayout controls = horizontal(); videoControls = controls;
        videoExpandButton = new Button(this);
        videoExpandButton.setText(videoExpanded ? "إعادة الواجهة" : "تكبير الفيديو");
        controls.addView(videoExpandButton, new LinearLayout.LayoutParams(0, dp(40), 1));
        uiFullscreenButton = new Button(this);
        uiFullscreenButton.setText(immersiveUi ? "إظهار أشرطة النظام" : "تكبير الواجهة");
        controls.addView(uiFullscreenButton, new LinearLayout.LayoutParams(0, dp(40), 1));
        video.addView(controls, new LinearLayout.LayoutParams(-1, dp(44)));
        videoExpandButton.setOnClickListener(v -> setVideoExpanded(!videoExpanded));
        uiFullscreenButton.setOnClickListener(v -> setImmersiveUi(!immersiveUi));
        videoBackButton = new Button(this);
        videoBackButton.setText("العودة إلى الواجهة  ↩");
        videoBackButton.setVisibility(videoExpanded ? View.VISIBLE : View.GONE);
        videoBackButton.setOnClickListener(v -> setVideoExpanded(false));
        video.addView(videoBackButton, new LinearLayout.LayoutParams(-1, dp(40)));

        urlInput = new EditText(this);
        urlInput.setSingleLine(true);
        urlInput.setTextColor(WHITE); urlInput.setHintTextColor(0xFF9AAAC0);
        urlInput.setHint("رابط بث مباشر أو M3U أو YouTube");
        urlInput.setTextSize(13); urlInput.setPadding(dp(10), 0, dp(10), 0);
        urlInput.setBackground(shape(0xFF26334B, 0xFF526987));
        video.addView(urlInput, new LinearLayout.LayoutParams(-1, dp(42)));

        LinearLayout actions = horizontal();
        Button play = new Button(this); play.setText("تشغيل الرابط");
        actions.addView(play, new LinearLayout.LayoutParams(0, dp(42), 1));
        Button playlist = new Button(this); playlist.setText("تحميل قائمة M3U");
        actions.addView(playlist, new LinearLayout.LayoutParams(0, dp(42), 1));
        video.addView(actions, new LinearLayout.LayoutParams(-1, dp(44)));
        play.setOnClickListener(v -> loadInput(urlInput.getText().toString().trim()));
        playlist.setOnClickListener(v -> loadM3U(urlInput.getText().toString().trim()));

        videoHost = new FrameLayout(this);
        videoHost.setBackgroundColor(Color.BLACK);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        playerView.setShutterBackgroundColor(Color.BLACK);
        videoHost.addView(playerView, new FrameLayout.LayoutParams(-1, -1));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.setVisibility(View.GONE);
        videoHost.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        video.addView(videoHost, new LinearLayout.LayoutParams(-1, 0, 1));
        status = label("أدخل رابط بث M3U8 أو اضغط تحميل قائمة M3U لاختيار قناة.", 12, 0xFFB9C5D7, false);
        video.addView(status);

        ScrollView infoScroll = new ScrollView(this);
        infoContainer = infoScroll;
        infoScroll.setFillViewport(false);
        infoScroll.addView(info, new ScrollView.LayoutParams(-1, -2));
        if (landscape) {
            body.setGravity(Gravity.TOP);
            body.addView(infoScroll, new LinearLayout.LayoutParams(0, -1, 0.40f));
            LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(0, -1, 0.60f); vp.setMargins(dp(6), 0, 0, 0);
            body.addView(video, vp);
        } else {
            body.addView(infoScroll, new LinearLayout.LayoutParams(-1, 0, 0.45f));
            LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, 0, 0.55f); vp.topMargin = dp(6);
            body.addView(video, vp);
        }
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout dock = horizontal(); dashboardDock = dock; dock.setGravity(Gravity.CENTER);
        addDockButton(dock, "قنوات M3U", () -> loadM3U(urlInput.getText().toString().trim()));
        addDockButton(dock, "YouTube", () -> { urlInput.setText("https://www.youtube.com"); loadInput("https://www.youtube.com"); });
        addDockButton(dock, "القرآن", () -> loadInput("https://quran.com"));
        addDockButton(dock, "الأذكار", () -> { dhikrIndex=(dhikrIndex+1)%adhkar.length; dhikr.setText(adhkar[dhikrIndex]); });
        addDockButton(dock, "إيقاف", () -> { if (exoPlayer != null) exoPlayer.stop(); if (webView != null) webView.loadUrl("about:blank"); status.setText("تم إيقاف التشغيل."); });
        root.addView(dock, new LinearLayout.LayoutParams(-1, dp(54)));
        setContentView(root);
        if (exoPlayer != null) playerView.setPlayer(exoPlayer);
        applyDisplayModes();
    }

    private void setVideoExpanded(boolean expanded) { videoExpanded = expanded; applyDisplayModes(); }
    private void setImmersiveUi(boolean enabled) { immersiveUi = enabled; applyDisplayModes(); }

    private void applyDisplayModes() {
        if (dashboardTop == null || dashboardBody == null || dashboardDock == null || infoContainer == null || videoPanel == null) return;
        dashboardTop.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        infoContainer.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        dashboardDock.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        if (videoExpandButton != null) videoExpandButton.setText(videoExpanded ? "إعادة الواجهة" : "تكبير الفيديو");
        if (videoBackButton != null) videoBackButton.setVisibility(videoExpanded ? View.VISIBLE : View.GONE);
        if (videoTitleView != null) videoTitleView.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        if (videoControls != null) videoControls.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        if (urlInput != null) urlInput.setVisibility(videoExpanded ? View.GONE : View.VISIBLE);
        if (videoControls != null && videoExpanded) videoControls.setVisibility(View.GONE);
        if (uiFullscreenButton != null) uiFullscreenButton.setText(immersiveUi ? "إظهار أشرطة النظام" : "تكبير الواجهة");
        if (videoExpanded) { videoPanel.setBackgroundColor(Color.BLACK); }
        else videoPanel.setBackground(shape(0xFF101B31, 0xFFB98A39));

        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE;
        if (immersiveUi || videoExpanded) flags |= View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        getWindow().getDecorView().setSystemUiVisibility(flags);

        if (videoExpanded) {
            if (infoContainer.getParent() instanceof ViewGroup) ((ViewGroup)infoContainer.getParent()).removeView(infoContainer);
            if (videoPanel.getParent() instanceof ViewGroup) ((ViewGroup)videoPanel.getParent()).removeView(videoPanel);
            dashboardBody.setOrientation(LinearLayout.VERTICAL);
            dashboardBody.addView(videoPanel, new LinearLayout.LayoutParams(-1, 0, 1f));
        } else {
            if (videoPanel.getParent() instanceof ViewGroup) ((ViewGroup)videoPanel.getParent()).removeView(videoPanel);
            if (infoContainer.getParent() instanceof ViewGroup) ((ViewGroup)infoContainer.getParent()).removeView(infoContainer);
            boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE
                || getResources().getConfiguration().smallestScreenWidthDp >= 600;
            dashboardBody.setOrientation(landscape ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
            if (landscape) {
                dashboardBody.addView(infoContainer, new LinearLayout.LayoutParams(0, -1, 0.40f));
                LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(0, -1, 0.60f); vp.setMargins(dp(6), 0, 0, 0);
                dashboardBody.addView(videoPanel, vp);
            } else {
                dashboardBody.addView(infoContainer, new LinearLayout.LayoutParams(-1, 0, 0.45f));
                LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(-1, 0, 0.55f); vp.topMargin = dp(6);
                dashboardBody.addView(videoPanel, vp);
            }
        }
    }

    private void loadInput(String input) {
        if (input == null || input.trim().isEmpty()) { status.setText("أدخل رابط بث أو فيديو أولاً."); return; }
        String url = input.trim();
        String lower = url.toLowerCase(Locale.ROOT);
        if (lower.contains("youtube.com") || lower.contains("youtu.be") || lower.contains("quran.com")) {
            showWebContent(url); return;
        }
        if (lower.matches(".*\\.m3u(?:[?#].*)?$")) { loadM3U(url); return; }
        playStream(url);
    }

    private void showWebContent(String url) {
        showingWebContent = true;
        if (exoPlayer != null) exoPlayer.pause();
        playerView.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        if (url.contains("youtube.com/watch") || url.contains("youtu.be/")) {
            String id = extractYoutubeId(url);
            if (id != null) {
                String html = "<html><body style='margin:0;background:#000'><iframe width='100%' height='100%' src='https://www.youtube.com/embed/" + id + "?playsinline=1&rel=0' frameborder='0' allow='autoplay; encrypted-media; picture-in-picture; fullscreen' allowfullscreen></iframe></body></html>";
                webView.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null);
            } else webView.loadUrl(url);
        } else webView.loadUrl(url);
        status.setText("تم فتح المحتوى داخل إطار المشاهدة. بعض فيديوهات YouTube قد تمنع التضمين.");
    }

    private String extractYoutubeId(String url) {
        try {
            Uri uri = Uri.parse(url); String host = uri.getHost() == null ? "" : uri.getHost();
            if (host.contains("youtu.be")) return uri.getLastPathSegment();
            if (host.contains("youtube.com")) {
                if (uri.getPath() != null && uri.getPath().startsWith("/embed/")) return uri.getLastPathSegment();
                return uri.getQueryParameter("v");
            }
        } catch (Exception ignored) {}
        return null;
    }

    private void playStream(String url) {
        try {
            initializePlayer();
            showingWebContent = false;
            webView.stopLoading(); webView.loadUrl("about:blank"); webView.setVisibility(View.GONE);
            playerView.setVisibility(View.VISIBLE);
            MediaItem.Builder item = new MediaItem.Builder().setUri(Uri.parse(url));
            String path = Uri.parse(url).getPath();
            if (path != null && path.toLowerCase(Locale.ROOT).endsWith(".m3u8")) item.setMimeType(MimeTypes.APPLICATION_M3U8);
            exoPlayer.setMediaItem(item.build());
            exoPlayer.prepare(); exoPlayer.play();
            status.setText("جارٍ تشغيل البث داخل التطبيق…");
        } catch (Exception e) { status.setText("الرابط غير صالح أو تعذر تشغيله: " + e.getMessage()); }
    }

    private void loadM3U(String url) {
        if (url == null || url.trim().isEmpty()) { status.setText("ضع رابط قائمة M3U في خانة الرابط أولاً."); return; }
        status.setText("جارٍ تحميل قائمة القنوات…");
        net.execute(() -> {
            try {
                HttpURLConnection c = (HttpURLConnection)new URL(url.trim()).openConnection();
                c.setConnectTimeout(15000); c.setReadTimeout(20000);
                c.setRequestProperty("User-Agent", "MawaqitSmartLauncher/1.3");
                StringBuilder body = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                    String line; while ((line = r.readLine()) != null) body.append(line).append('\n');
                } finally { c.disconnect(); }
                ArrayList<String> names = new ArrayList<>();
                ArrayList<String> urls = new ArrayList<>();
                String pendingName = null;
                for (String raw : body.toString().split("\\n")) {
                    String line = raw.trim();
                    if (line.isEmpty()) continue;
                    if (line.startsWith("#EXTINF")) {
                        int comma = line.lastIndexOf(',');
                        pendingName = comma >= 0 && comma < line.length()-1 ? line.substring(comma+1).trim() : "قناة " + (names.size()+1);
                    } else if (!line.startsWith("#") && (line.startsWith("http://") || line.startsWith("https://"))) {
                        urls.add(line); names.add(pendingName == null ? "قناة " + (names.size()+1) : pendingName); pendingName = null;
                    }
                }
                runOnUiThread(() -> showPlaylist(names, urls));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("تعذر تحميل القائمة. تحقق من الرابط والاتصال.") );
            }
        });
    }

    private void showPlaylist(ArrayList<String> names, ArrayList<String> urls) {
        if (names.isEmpty()) { status.setText("لم يتم العثور على قنوات في قائمة M3U."); return; }
        status.setText("تم العثور على " + names.size() + " قناة.");
        String[] items = names.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("اختر قناة للتشغيل")
            .setItems(items, (dialog, which) -> playStream(urls.get(which)))
            .setNegativeButton("إغلاق", null).show();
    }

    private void addDockButton(LinearLayout dock, String title, Runnable action) {
        Button b = new Button(this); b.setText(title); b.setTextSize(11);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(48), 1);
        lp.setMargins(dp(2), 0, dp(2), 0); dock.addView(b, lp);
        b.setOnClickListener(v -> action.run());
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (playerView != null) playerView.setPlayer(null);
        if (webView != null) {
            webView.stopLoading();
            if (webView.getParent() instanceof ViewGroup) ((ViewGroup)webView.getParent()).removeView(webView);
            webView.destroy();
        }
        buildDashboard(); updateClock(); refreshData();
    }

    private Runnable ticker = new Runnable() { @Override public void run() { updateClock(); handler.postDelayed(this, 1000); } };
    private Runnable refreshTicker = new Runnable() { @Override public void run() { refreshData(); handler.postDelayed(this, 30*60*1000); } };
    private void updateClock() {
        Date now = new Date();
        if (clock != null) clock.setText(new SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(now));
        if (date != null) date.setText(new SimpleDateFormat("EEEE، dd.MM.yyyy", new Locale("ar")).format(now));
    }
    private void refreshData() {
        net.execute(() -> {
            try {
                String raw = get("https://api.aladhan.com/v1/timings?latitude=54.3233&longitude=10.1228&method=3");
                JSONObject data = new JSONObject(raw).getJSONObject("data"); JSONObject t = data.getJSONObject("timings");
                String pt = "الفجر " + clean(t.optString("Fajr")) + "  •  الظهر " + clean(t.optString("Dhuhr")) +
                    "\nالعصر " + clean(t.optString("Asr")) + "  •  المغرب " + clean(t.optString("Maghrib")) + "  •  العشاء " + clean(t.optString("Isha"));
                JSONObject h = data.getJSONObject("date").getJSONObject("hijri");
                String ht = "التاريخ الهجري: " + h.optString("day") + " " + h.getJSONObject("month").optString("ar") + " " + h.optString("year") + " هـ";
                runOnUiThread(() -> { prayer.setText(pt); hijri.setText(ht); nextPrayer.setText("مواقيت الصلاة محدّثة لمدينة كيل"); });
            } catch (Exception e) { runOnUiThread(() -> { if (status != null) status.setText("تعذر تحديث مواقيت الصلاة. تحقق من الإنترنت."); }); }
            try {
                String raw = get("https://api.open-meteo.com/v1/forecast?latitude=54.3233&longitude=10.1228&current=temperature_2m,apparent_temperature&timezone=Europe%2FBerlin");
                JSONObject cur = new JSONObject(raw).getJSONObject("current");
                String wt = "كيل: " + cur.optDouble("temperature_2m") + "°C  •  المحسوسة " + cur.optDouble("apparent_temperature") + "°C";
                runOnUiThread(() -> weather.setText(wt));
            } catch (Exception ignored) {}
        });
    }
    private String get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(u).openConnection(); c.setConnectTimeout(10000); c.setReadTimeout(10000);
        try (InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
            byte[] b=new byte[4096]; int n; while((n=in.read(b))!=-1) out.write(b,0,n); return out.toString("UTF-8");
        } finally { c.disconnect(); }
    }
    private String clean(String s) { return s == null ? "--:--" : s.split(" ")[0]; }
    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null); net.shutdownNow();
        if (exoPlayer != null) { exoPlayer.release(); exoPlayer = null; }
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
