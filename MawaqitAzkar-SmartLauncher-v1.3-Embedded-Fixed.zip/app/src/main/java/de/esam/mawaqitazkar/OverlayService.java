package de.esam.mawaqitazkar;

import android.app.*;
import android.content.*;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;

public class OverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private TextView clock, date, hijri, weather, prayer, adhkar;
    private Handler handler = new Handler(Looper.getMainLooper());
    private ExecutorService net = Executors.newSingleThreadExecutor();
    private int dhikrIndex = 0;
    private String[] adhkarList = {
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
        "أستغفر الله العظيم وأتوب إليه",
        "لا إله إلا الله وحده لا شريك له",
        "اللهم صلِّ وسلم على نبينا محمد",
        "سبحان الله، والحمد لله، ولا إله إلا الله، والله أكبر",
        "لا حول ولا قوة إلا بالله"
    };
    private String prayerText = "الفجر  —   الظهر  —   العصر  —   المغرب  —   العشاء";
    private String hijriText = "التاريخ الهجري: جارٍ التحميل…";
    private String weatherText = "الطقس: جارٍ التحميل…";
    private Runnable ticker;

    private int dp(float x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER); t.setPadding(dp(3), dp(3), dp(3), dp(3)); return t;
    }

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = new Notification.Builder(this, "floating_panel")
            .setContentTitle("مواقيت وأذكار")
            .setContentText("اللوحة العائمة تعمل")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true).build();
        startForeground(7, n);
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        buildPanel();
        refreshPrayerAndWeather();
        ticker = new Runnable() {
            @Override public void run() {
                updateClock();
                adhkar.setText("📿 " + adhkarList[dhikrIndex % adhkarList.length]);
                dhikrIndex++;
                handler.postDelayed(this, 15000);
            }
        };
        handler.post(ticker);
        handler.postDelayed(new Runnable() {
            @Override public void run() { refreshPrayerAndWeather(); handler.postDelayed(this, 30*60*1000); }
        }, 30*60*1000);
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel("floating_panel", "اللوحة العائمة", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }

    private void buildPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(10), dp(7), dp(10), dp(9));
        BitmapDrawable kaaba = new BitmapDrawable(getResources(),
            android.graphics.BitmapFactory.decodeResource(getResources(), R.drawable.kaaba_background));
        kaaba.setGravity(Gravity.FILL);
        LayerDrawable background = new LayerDrawable(new android.graphics.drawable.Drawable[] {
            kaaba, new ColorDrawable(0x66071310)
        });
        box.setBackground(background);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = text("مواقيت وأذكار  •  كيل", 13, 0xFFFFD98A);
        brand.setGravity(Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        bar.addView(brand, new LinearLayout.LayoutParams(0, dp(32), 1));
        TextView close = text("×", 23, 0xFFFFFFFF);
        bar.addView(close, new LinearLayout.LayoutParams(dp(34), dp(32)));
        box.addView(bar);
        clock = text("--:--:--", 27, 0xFFFFFFFF); box.addView(clock);
        date = text("", 12, 0xFFE4EEE8); box.addView(date);
        hijri = text(hijriText, 12, 0xFFFFD98A); box.addView(hijri);
        weather = text(weatherText, 13, 0xFFFFFFFF); box.addView(weather);
        View line = new View(this); line.setBackgroundColor(0x667ED6A5);
        box.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        prayer = text(prayerText, 12, 0xFFFFFFFF); box.addView(prayer);
        adhkar = text("📿 " + adhkarList[0], 14, 0xFFFFE6AE);
        adhkar.setMinHeight(dp(48)); box.addView(adhkar);

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            dp(310), WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.RIGHT;
        p.x = dp(10); p.y = dp(100);
        wm.addView(box, p);
        panel = box;

        final int[] start = new int[4];
        bar.setOnTouchListener((v,e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                start[0] = p.x; start[1] = p.y; start[2] = (int)e.getRawX(); start[3] = (int)e.getRawY(); return true;
            } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                p.x = start[0] - ((int)e.getRawX() - start[2]);
                p.y = start[1] + ((int)e.getRawY() - start[3]);
                wm.updateViewLayout(panel, p); return true;
            }
            return true;
        });
        close.setOnClickListener(v -> stopSelf());
    }

    private void updateClock() {
        Date now = new Date();
        clock.setText(new SimpleDateFormat("HH:mm:ss", Locale.GERMANY).format(now));
        date.setText(new SimpleDateFormat("EEEE، dd.MM.yyyy", new Locale("ar")).format(now));
    }

    private void refreshPrayerAndWeather() {
        net.execute(() -> {
            try {
                // Kiel coordinates; AlAdhan calculation method 3 (Muslim World League).
                String raw = get("https://api.aladhan.com/v1/timings?latitude=54.3233&longitude=10.1228&method=3");
                JSONObject data = new JSONObject(raw).getJSONObject("data");
                JSONObject t = data.getJSONObject("timings");
                String pt = "الفجر " + clean(t.optString("Fajr")) + "  •  الظهر " + clean(t.optString("Dhuhr")) +
                    "\nالعصر " + clean(t.optString("Asr")) + "  •  المغرب " + clean(t.optString("Maghrib")) +
                    "  •  العشاء " + clean(t.optString("Isha"));
                JSONObject h = data.getJSONObject("date").getJSONObject("hijri");
                String ht = "التاريخ الهجري: " + h.optString("day") + " " +
                    h.getJSONObject("month").optString("ar") + " " + h.optString("year") + " هـ";
                runOnUi(() -> { prayer.setText(pt); hijri.setText(ht); });
            } catch (Exception ignored) {}
            try {
                String raw = get("https://api.open-meteo.com/v1/forecast?latitude=54.3233&longitude=10.1228&current=temperature_2m,apparent_temperature,weather_code&timezone=Europe%2FBerlin");
                JSONObject cur = new JSONObject(raw).getJSONObject("current");
                String wt = "🌤️ كيل: " + cur.optDouble("temperature_2m") + "°C  •  المحسوسة " + cur.optDouble("apparent_temperature") + "°C";
                runOnUi(() -> weather.setText(wt));
            } catch (Exception ignored) {}
        });
    }

    private String get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(u).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(10000); c.setRequestMethod("GET");
        try (InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] b = new byte[4096]; int n; while ((n=in.read(b))!=-1) out.write(b,0,n);
            return out.toString("UTF-8");
        } finally { c.disconnect(); }
    }
    private String clean(String s) { return s == null ? "--:--" : s.split(" ")[0]; }
    private void runOnUi(Runnable r) { handler.post(r); }

    @Override public int onStartCommand(Intent i, int flags, int id) { return START_STICKY; }
    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (panel != null) try { wm.removeView(panel); } catch (Exception ignored) {}
        net.shutdownNow();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent i) { return null; }
}
